#define bitmapdatatype unsigned short*

